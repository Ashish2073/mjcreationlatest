<?php echo e($userotp); ?>

<?php /**PATH C:\xampp\htdocs\mjcreationlatest\resources\views/mail/otpsendmail.blade.php ENDPATH**/ ?>