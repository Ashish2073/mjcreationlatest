<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>" type="text/css" media="screen" />
    <link rel="stylesheet" href="<?php echo e(asset('fontawesome/font-awesome.min.css')); ?>" type="text/css" media="screen" />
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>" type="text/css" media="screen" />




    <link rel="stylesheet" href="<?php echo e(asset('css/fontgoogleapis.css')); ?>" type="text/css" media="screen" />
    <link rel="stylesheet" href="<?php echo e(asset('fontawesome/font-awesome.w3.css')); ?>" type="text/css" media="screen" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/vendor.bundle.base.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/maps/style.css.map')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/adminstyle.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('fontawesome/font-awesome.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('fontawesome/font-awesome.w3.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendorcss/ti-icons/css/themify-icons.css')); ?>">






    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/datatables/boostrap.min.css')); ?>">

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/datatables/boostrap5.css')); ?>">

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/toaster.min.css')); ?>">

    <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.js')); ?>"></script>

    <script src="<?php echo e(asset('js/toaster.min.js')); ?>"></script>
    <script src="<?php echo e(asset('graph/Chart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/vendor.bundle.base.js')); ?>"></script>
    <script src="<?php echo e(asset('js/documentation.js')); ?>"></script>
    <script src="<?php echo e(asset('js/file-upload.js')); ?>"></script>
    <script src="<?php echo e(asset('js/hoverable-collapse.js')); ?>"></script>
    <script src="<?php echo e(asset('js/tabs.js')); ?>"></script>

    <script src="<?php echo e(asset('js/todolist.js')); ?>"></script>
    <script src="<?php echo e(asset('js/tooltips.js')); ?>"></script>
    <script src="<?php echo e(asset('js/off-canvas.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dashboard.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.validation.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/additional.method.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.form.js')); ?>"></script>
    <script src="<?php echo e(asset('js/main.js')); ?>"></script>
    <script src="<?php echo e(asset('tailwindcss/tailwind.js')); ?>"></script>
    <script src="<?php echo e(asset('ckeditor5/ckeditor.js')); ?>"></script>
    

    
    <script src="<?php echo e(asset('js/datatables/datatables2.0.5.js')); ?>"></script>
    
    <script src="<?php echo e(asset('js/datatables/boostrap5.js')); ?>"></script>




    









    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>

<body class="">





    <?php echo $__env->make('website.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('website.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    <script src="<?php echo e(asset('vendor/livewire/livewire.js')); ?>"></script>
    <?php echo $__env->yieldContent('page-script'); ?>

    <script src="<?php echo e(asset('js/template.js')); ?>"></script>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\mjcreationlatest\resources\views/website/layout/main.blade.php ENDPATH**/ ?>